const usuarioLink = "http://"+EnderecoLink+"public_html/api/usuario/"
function requisitar(metodo, dados, funcao) {
    fetch(usuarioLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
const formulario = document.querySelector("#formcad")
if(formulario){
    formulario.addEventListener("submit", (evento) => {
        evento.preventDefault()
        let dados = new FormData(formulario)
        requisitar("POST", dados, (retorno) => {
            toastbody.innerHTML = retorno.data
            toastElement.show()
            formulario.reset()
        })
    })
    
}

const updateUser = document.querySelector("#formupdate")
const nomeUsuario = document.getElementById("nome")
const sobrenomeUsuario = document.getElementById("sobrenome")
const email = document.getElementById("email")
dados = [0,0]

updateUser.addEventListener("submit", (e)=>{
    e.preventDefault()
    dados[0] = nomeUsuario.value
    dados[1] = sobrenomeUsuario.value
    requisitar("PUT", JSON.stringify({
        nome: dados[0],
        sobrenome: dados[1]
    }), (retorno)=>{
        console.log(retorno.data)
        toastbody.innerHTML = retorno.data
        toastElement.show()
    })
})

document.addEventListener("DOMContentLoaded", ()=>{
    listar()
})  

function listar(){
    requisitar("GET", null, (retorno) => {
        nomeUsuario.value = retorno.data.nome
        sobrenomeUsuario.value = retorno.data.sobrenome
        email.value = retorno.data.email
    })
}