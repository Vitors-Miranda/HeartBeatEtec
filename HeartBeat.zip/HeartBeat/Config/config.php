<?php
    const DBDRIVE = "mysql";
    const DBHOST = "localhost";
    const DBNAME = "heartbeat";
    const DBUSER = "root";
    const DBPASS = "";